# Adaptive Wheel (Fabric, Minecraft 26.3)

A personal, from-scratch implementation of the *idea* of a head-worn wheel that
adapts to damage, plus a holy sword for hunting the undead. It contains none of
another mod's code, models, animations or sounds: visuals are simple
placeholders and sounds/particles are vanilla.

## Build

Needs JDK 25 and Gradle 9.6 (or newer), plus internet for the first build.

    cd adaptive_wheel
    gradle build            # or: gradle wrapper --gradle-version 9.6.0  then ./gradlew build

The jar appears in `build/libs/adaptive-wheel-1.0.0.jar`. Put it in your `mods`
folder together with Fabric API (0.166.2+26.3 or newer) and Fabric Loader.

## Items

- Wheel of Adaptation (head slot; right-click to equip). Crafting: gold / clock / totem of undying.
- Sword of Extermination. Crafting: golden apples, gold ingots, diamond sword.
- Or use: `/give @s adaptive_wheel:adaptation_wheel` and `/give @s adaptive_wheel:extermination_sword`.

## What it does

Wheel
- Each damage source is its own "phenomenon" (mob family, projectile type, damage type).
- Tiers: physical 3 turns, magic/effects 5, elite mobs 6, bosses (Warden, Wither, Ender Dragon) 8.
- Every 2 hits = one turn; hit again within 1 second and the wheel turns faster.
- Each turn reduces that damage and heals 30% of your missing health.
- Full adaptation: hits do nothing (no damage, no knockback, no on-hit effects) and you heal fully.
- Zombie/skeleton/spider families share progress. Fire, burning, lava, hot floor help each other.
- Passive regeneration grows with each completed adaptation.
- Damage bonus: up to +50% vs mobs you adapted to, +1% per completed adaptation (max +25%).
- Progress HUD top-left. Take the wheel off and everything resets. Dying resets everything.
- Progress is saved with the player.

Sword
- Undead take 1.75x damage; undead at or below 20% health are purified (the Wither is immune).
- Zombie villagers are cured instead of killed.
- Right-click Positive Slash: damages mobs up to 12 blocks, cuts blocks up to 32 blocks, 7 s cooldown.
  Bedrock, command blocks and other unbreakable blocks, containers and the ender chest are safe.
  Block cutting is off in Adventure/Spectator.

## Not included (compared to the original description)

Custom 3D wheel above the head, wheel animations, custom sounds, other languages,
the `/woa:mode` command (use crafting or /give).

## If the build complains

This was written against the 26.1/26.2 docs and could not be compiled where it was
written. The places most likely to need a one-line fix on 26.3:

- `ModItems`: import path of `Equippable` or `Item.Properties#sword(...)`.
- `LivingEntityMixin`: the `hurtServer` method signature.
- `AdaptiveWheelClient`: `GuiGraphicsExtractor` method names (`fill`, `outline`, `text`).
- `ExterminationSwordItem`: cooldown calls (`getCooldowns().isOnCooldown/addCooldown`).
- `build.gradle`/`gradle.properties`: Loom version (`1.17-SNAPSHOT`) and Fabric Loader version.
