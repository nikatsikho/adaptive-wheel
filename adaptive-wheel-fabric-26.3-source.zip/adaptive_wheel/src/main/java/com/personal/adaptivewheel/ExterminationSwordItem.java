package com.personal.adaptivewheel;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Right-click: Positive Slash. */
public class ExterminationSwordItem extends Item {
	private static final double MOB_RANGE = 12.0;
	private static final double BLOCK_RANGE = 32.0;
	private static final float SLASH_DAMAGE = 8.0f;
	private static final int COOLDOWN_TICKS = 7 * 20;

	public ExterminationSwordItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (player.getCooldowns().isOnCooldown(stack)) {
			return InteractionResult.FAIL;
		}
		if (!(level instanceof ServerLevel sl)) {
			return InteractionResult.SUCCESS; // client: just swing
		}

		Vec3 start = player.getEyePosition();
		Vec3 dir = player.getLookAngle().normalize();

		// 1) Damage mobs along the wave (the mixin adds the 1.75x undead bonus).
		Set<LivingEntity> victims = new HashSet<>();
		for (double d = 1.0; d <= MOB_RANGE; d += 1.0) {
			Vec3 p = start.add(dir.scale(d));
			AABB box = new AABB(p, p).inflate(1.25);
			for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, box)) {
				if (e != player && e.isAlive()) victims.add(e);
			}
		}
		for (LivingEntity e : victims) {
			e.hurtServer(sl, sl.damageSources().playerAttack(player), SLASH_DAMAGE);
		}

		// 2) Cut blocks along the wave (not in Adventure / Spectator).
		if (player.getAbilities().mayBuild) {
			Set<BlockPos> seen = new LinkedHashSet<>();
			for (double d = 1.0; d <= BLOCK_RANGE; d += 0.5) {
				BlockPos pos = BlockPos.containing(start.add(dir.scale(d)));
				if (!seen.add(pos)) continue;
				if (canCut(sl, pos)) {
					sl.destroyBlock(pos, false, player);
				}
			}
		}

		// 3) Visuals, sound, cooldown.
		for (double d = 1.0; d <= MOB_RANGE; d += 1.0) {
			Vec3 p = start.add(dir.scale(d));
			sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 2, 0.05, 0.05, 0.05, 0.0);
		}
		sl.playSound(null, player.getX(), player.getY(), player.getZ(),
			SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 0.7f);
		player.getCooldowns().addCooldown(stack, COOLDOWN_TICKS);
		return InteractionResult.SUCCESS;
	}

	private static boolean canCut(ServerLevel level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		if (state.isAir()) return false;
		if (!state.getFluidState().isEmpty()) return false;
		if (state.getDestroySpeed(level, pos) < 0) return false;          // bedrock, command/structure blocks, barrier...
		if (state.is(Blocks.ENDER_CHEST)) return false;
		return !(level.getBlockEntity(pos) instanceof Container);          // chests, barrels, furnaces... stay safe
	}
}
