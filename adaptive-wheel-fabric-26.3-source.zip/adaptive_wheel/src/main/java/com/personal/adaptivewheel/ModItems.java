package com.personal.adaptivewheel;

import java.util.function.Function;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.Equippable;

public final class ModItems {
	/** Worn on the head (right-click to equip, or place it in the helmet slot). */
	public static final Item WHEEL = register("adaptation_wheel", Item::new,
		new Item.Properties()
			.stacksTo(1)
			.rarity(Rarity.EPIC)
			.component(DataComponents.EQUIPPABLE, Equippable.builder(EquipmentSlot.HEAD).build()));

	public static final Item SWORD = register("extermination_sword", ExterminationSwordItem::new,
		new Item.Properties()
			.rarity(Rarity.EPIC)
			.sword(ToolMaterial.DIAMOND, 3.0F, -2.4F));

	private ModItems() {}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, AdaptiveWheel.id(name));
		return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
	}

	/** Forces the static initializer to run. */
	public static void init() {}
}
