package com.personal.adaptivewheel;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Pure data helpers shared by server logic and the client HUD (no Minecraft types here).
 *
 * Progress is stored per "phenomenon" key as a number of points. Every
 * POINTS_PER_TURN points the wheel turns one handle. A phenomenon is fully
 * adapted once it has earned tier(key) turns.
 *
 * Serialized form (attachment value): "key=points|key=points".
 */
public final class AdaptationState {
	public static final int POINTS_PER_TURN = 2;

	private static final Set<String> BOSS = Set.of("warden", "wither", "ender_dragon");
	private static final Set<String> ELITE = Set.of(
		"ravager", "evoker", "vindicator", "piglin_brute", "elder_guardian", "illusioner");
	private static final Set<String> MAGIC = Set.of(
		"magic", "indirectMagic", "wither", "dragonBreath", "sonic_boom", "sonicBoom");

	/** Fire-like sources prepare you a little for each other. */
	public static final List<String> FIRE_GROUP = List.of(
		"env:inFire", "env:onFire", "env:lava", "env:hotFloor");

	private AdaptationState() {}

	/** Members of one mob family share a single adaptation. */
	public static String family(String entityPath) {
		return switch (entityPath) {
			case "zombie", "husk", "drowned", "zombie_villager" -> "zombie";
			case "skeleton", "stray", "bogged" -> "skeleton";
			case "spider", "cave_spider" -> "spider";
			default -> entityPath;
		};
	}

	/** Number of wheel turns needed to fully adapt to this phenomenon. */
	public static int tier(String key) {
		if (key.startsWith("mob:")) {
			String t = key.substring(4);
			if (BOSS.contains(t)) return 8;
			if (ELITE.contains(t)) return 6;
			return 3;
		}
		if (key.startsWith("env:")) {
			return MAGIC.contains(key.substring(4)) ? 5 : 3;
		}
		return 3;
	}

	public static int need(String key) {
		return tier(key) * POINTS_PER_TURN;
	}

	public static int turns(Map<String, Integer> m, String key) {
		return Math.min(tier(key), m.getOrDefault(key, 0) / POINTS_PER_TURN);
	}

	public static boolean complete(Map<String, Integer> m, String key) {
		return m.getOrDefault(key, 0) >= need(key);
	}

	public static int completedCount(Map<String, Integer> m) {
		int n = 0;
		for (String k : m.keySet()) {
			if (complete(m, k)) n++;
		}
		return n;
	}

	public static int totalTurns(Map<String, Integer> m) {
		int n = 0;
		for (String k : m.keySet()) {
			n += turns(m, k);
		}
		return n;
	}

	public static Map<String, Integer> parse(String s) {
		Map<String, Integer> m = new LinkedHashMap<>();
		if (s == null || s.isEmpty()) return m;
		for (String part : s.split("\\|")) {
			int i = part.lastIndexOf('=');
			if (i <= 0) continue;
			try {
				m.put(part.substring(0, i), Integer.parseInt(part.substring(i + 1)));
			} catch (NumberFormatException ignored) {
				// skip corrupt entry
			}
		}
		return m;
	}

	public static String format(Map<String, Integer> m) {
		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, Integer> e : m.entrySet()) {
			if (e.getValue() <= 0) continue;
			if (sb.length() > 0) sb.append('|');
			sb.append(e.getKey()).append('=').append(e.getValue());
		}
		return sb.toString();
	}

	/** "mob:cave_spider" -> "Cave Spider", "env:inFire" -> "In Fire". */
	public static String pretty(String key) {
		String s = key.contains(":") ? key.substring(key.indexOf(':') + 1) : key;
		s = s.replaceAll("([a-z])([A-Z])", "$1 $2").replace('_', ' ');
		StringBuilder out = new StringBuilder();
		boolean up = true;
		for (char c : s.toCharArray()) {
			out.append(up ? Character.toUpperCase(c) : c);
			up = c == ' ';
		}
		return out.toString();
	}
}
