package com.personal.adaptivewheel.client;

import java.util.Map;

import com.personal.adaptivewheel.AdaptationState;
import com.personal.adaptivewheel.AdaptiveWheel;
import com.personal.adaptivewheel.ModItems;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;

/** Progress HUD: which phenomenon you are adapting to, how far along, and how many are done. */
public class AdaptiveWheelClient implements ClientModInitializer {
	private static final int GOLD = 0xFFE8C547;
	private static final int GREY = 0xFF555555;

	private static double angle = 0.0;

	@Override
	public void onInitializeClient() {
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, AdaptiveWheel.id("progress"),
			AdaptiveWheelClient::extract);
	}

	private static void extract(GuiGraphicsExtractor g, DeltaTracker tracker) {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (player == null || mc.options.hideGui) return;
		if (!player.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.WHEEL)) return;

		Map<String, Integer> m = AdaptationState.parse(player.getAttachedOrElse(AdaptiveWheel.DATA, ""));

		// The phenomenon you are closest to finishing (that is not finished yet).
		String current = null;
		double best = -1;
		for (Map.Entry<String, Integer> e : m.entrySet()) {
			if (AdaptationState.complete(m, e.getKey())) continue;
			double f = e.getValue() / (double) AdaptationState.need(e.getKey());
			if (f > best) {
				best = f;
				current = e.getKey();
			}
		}
		int adapted = AdaptationState.completedCount(m);
		int turns = current == null ? 0 : AdaptationState.turns(m, current);

		int x = 6, y = 6, w = 132, h = 46;
		g.fill(x, y, x + w, y + h, 0x99000000);
		g.outline(x, y, w, h, GOLD);

		// Wheel emblem: 8 handles, one lights up per turn; it eases towards the current angle.
		double target = Math.toRadians(45.0 * turns);
		angle += (target - angle) * 0.12;
		if (current == null) angle += 0.01; // idle drift
		int cx = x + 20, cy = y + h / 2;
		for (int i = 0; i < 8; i++) {
			double a = angle + i * Math.PI / 4.0;
			int px = cx + (int) Math.round(Math.cos(a) * 12);
			int py = cy + (int) Math.round(Math.sin(a) * 12);
			boolean lit = current == null ? adapted > 0 : i < turns;
			g.fill(px - 1, py - 1, px + 2, py + 2, lit ? GOLD : GREY);
		}
		g.fill(cx - 2, cy - 2, cx + 3, cy + 3, adapted > 0 ? GOLD : 0xFF999999);

		Font font = mc.font;
		int tx = x + 42;
		g.text(font, Component.literal("Wheel of Adaptation"), tx, y + 5, GOLD, true);
		if (current == null) {
			g.text(font, Component.literal("Waiting for pain..."), tx, y + 17, 0xFFFFFFFF, true);
		} else {
			g.text(font, Component.literal(AdaptationState.pretty(current)), tx, y + 17, 0xFFFFFFFF, true);
			int bw = w - 48;
			int filled = (int) Math.round(bw * Math.min(1.0, best));
			g.fill(tx, y + 28, tx + bw, y + 33, 0xFF333333);
			g.fill(tx, y + 28, tx + filled, y + 33, GOLD);
		}
		g.text(font, Component.literal("Adapted: " + adapted), tx, y + 35, 0xFFAAAAAA, true);
	}
}
