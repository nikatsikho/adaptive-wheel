package com.personal.adaptivewheel.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.personal.adaptivewheel.Adaptation;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	/**
	 * Rescales the damage amount of every hit: adaptation reduces it for a wheel
	 * wearer, and wheel/sword bonuses raise it for the attacker.
	 */
	@ModifyVariable(method = "hurtServer", at = @At("HEAD"), argsOnly = true, ordinal = 0)
	private float adaptive_wheel$modifyDamage(float amount, ServerLevel level, DamageSource source, float originalAmount) {
		return Adaptation.modifyDamage((LivingEntity) (Object) this, source, amount);
	}
}
