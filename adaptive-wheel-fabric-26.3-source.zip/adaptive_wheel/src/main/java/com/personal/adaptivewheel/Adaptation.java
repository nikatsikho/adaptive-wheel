package com.personal.adaptivewheel;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/** Server-side adaptation rules. */
public final class Adaptation {
	private static final int SWARM_WINDOW_TICKS = 20;
	private static final Map<UUID, Map<String, Long>> LAST_HIT = new HashMap<>();

	private Adaptation() {}

	// ------------------------------------------------------------------ helpers

	public static boolean wearsWheel(LivingEntity e) {
		return e instanceof Player && e.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.WHEEL);
	}

	private static Map<String, Integer> read(Player p) {
		return AdaptationState.parse(p.getAttachedOrElse(AdaptiveWheel.DATA, ""));
	}

	private static void write(Player p, Map<String, Integer> m) {
		p.setAttached(AdaptiveWheel.DATA, AdaptationState.format(m));
	}

	private static String typeName(Entity e) {
		return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
	}

	/** Which "phenomenon" does this damage belong to? */
	static String keyFor(DamageSource src, LivingEntity victim) {
		Entity direct = src.getDirectEntity();
		Entity cause = src.getEntity();
		// arrows, fireballs, tridents, primed TNT... (a non-living direct source that is not the attacker)
		if (direct != null && direct != cause && !(direct instanceof LivingEntity)) {
			return "proj:" + typeName(direct);
		}
		if (cause != null && cause != victim) {
			if (cause instanceof Player) return "player";
			return "mob:" + AdaptationState.family(typeName(cause));
		}
		return "env:" + src.getMsgId();
	}

	private static boolean isUndead(LivingEntity e) {
		return e.getType().is(EntityTypeTags.UNDEAD);
	}

	// ----------------------------------------------------------- damage hooks

	/** Called from the LivingEntity#hurtServer mixin: rescale the damage amount. */
	public static float modifyDamage(LivingEntity victim, DamageSource src, float amount) {
		if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return amount;
		float a = amount;

		// Wheel wearer taking damage: reduce by adaptation progress.
		if (victim instanceof ServerPlayer sp && wearsWheel(sp)) {
			String key = keyFor(src, sp);
			Map<String, Integer> m = read(sp);
			float fraction = Math.min(1f, AdaptationState.turns(m, key) / (float) AdaptationState.tier(key));
			a *= (1f - fraction);
		}

		// Wheel wearer / sword wielder dealing damage.
		if (src.getEntity() instanceof ServerPlayer atk && atk != victim) {
			if (wearsWheel(atk)) {
				Map<String, Integer> m = read(atk);
				float bonus = Math.min(0.25f, 0.01f * AdaptationState.completedCount(m));
				if (!(victim instanceof Player)) {
					String mobKey = "mob:" + AdaptationState.family(typeName(victim));
					float progress = Math.min(1f, m.getOrDefault(mobKey, 0) / (float) AdaptationState.need(mobKey));
					bonus += 0.5f * progress;
				}
				a *= (1f + bonus);
			}
			if (atk.getMainHandItem().is(ModItems.SWORD) && isUndead(victim)) {
				a *= 1.75f;
			}
		}
		return a;
	}

	/** Fabric ALLOW_DAMAGE: returning false cancels the hit completely (no damage, no knockback). */
	public static boolean allowDamage(LivingEntity entity, DamageSource src, float amount) {
		// Sword cures zombie villagers instead of killing them.
		if (entity.getType() == EntityType.ZOMBIE_VILLAGER
				&& src.getEntity() instanceof ServerPlayer atk
				&& atk.getMainHandItem().is(ModItems.SWORD)) {
			cureZombieVillager(entity, atk);
			return false;
		}

		if (entity instanceof ServerPlayer sp && wearsWheel(sp)
				&& !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
			String key = keyFor(src, sp);
			if (AdaptationState.complete(read(sp), key)) {
				return false; // fully adapted: it still "hits", but does nothing
			}
		}
		return true;
	}

	/** Fabric AFTER_DAMAGE: count the hit towards adaptation, and handle purification. */
	public static void afterDamage(LivingEntity entity, DamageSource src, float baseDamage, float damageTaken, boolean blocked) {
		if (entity instanceof ServerPlayer sp && wearsWheel(sp)
				&& baseDamage > 0 && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
			recordHit(sp, src);
		}
		if (src.getEntity() instanceof ServerPlayer atk) {
			tryPurify(atk, entity);
		}
	}

	// ------------------------------------------------------------ adaptation

	private static void recordHit(ServerPlayer p, DamageSource src) {
		String key = keyFor(src, p);
		Map<String, Integer> m = read(p);
		int need = AdaptationState.need(key);
		int before = m.getOrDefault(key, 0);
		if (before >= need) return;

		long now = p.level().getGameTime();
		Long prev = LAST_HIT.computeIfAbsent(p.getUUID(), u -> new HashMap<>()).put(key, now);
		boolean fast = prev != null && now - prev <= SWARM_WINDOW_TICKS;

		int after = Math.min(need, before + (fast ? 2 : 1));
		int turnsBefore = before / AdaptationState.POINTS_PER_TURN;
		int turnsAfter = after / AdaptationState.POINTS_PER_TURN;
		int totalBefore = AdaptationState.totalTurns(m);
		m.put(key, after);

		if (turnsAfter > turnsBefore) {
			boolean done = after >= need;

			// Kin adaptation: fire-like sources help each other (never completing for free).
			if (AdaptationState.FIRE_GROUP.contains(key)) {
				for (String other : AdaptationState.FIRE_GROUP) {
					if (other.equals(key)) continue;
					int cap = AdaptationState.need(other) - 1;
					int cur = m.getOrDefault(other, 0);
					if (cur < cap) m.put(other, cur + 1);
				}
			}

			if (done) {
				p.setHealth(p.getMaxHealth());
				play(p, SoundEvents.BEACON_ACTIVATE, 1.0f, 1.2f);
				play(p, SoundEvents.PLAYER_LEVELUP, 0.8f, 0.8f);
				burst(p, 30);
			} else {
				float missing = p.getMaxHealth() - p.getHealth();
				if (missing > 0) p.heal(missing * 0.3f);
				if (totalBefore == 0) {
					play(p, SoundEvents.ANVIL_LAND, 0.6f, 0.6f);   // stuck first turn
				} else if (fast) {
					play(p, SoundEvents.IRON_TRAPDOOR_OPEN, 0.9f, 1.6f); // fast turn
				} else {
					play(p, SoundEvents.IRON_TRAPDOOR_OPEN, 0.9f, 0.8f); // normal turn
				}
			}
		}
		write(p, m);
	}

	/** Once per second per player. */
	public static void tickPlayer(ServerPlayer p) {
		if (!wearsWheel(p)) {
			// "Take it off and everything it gave you resets to zero."
			if (!p.getAttachedOrElse(AdaptiveWheel.DATA, "").isEmpty()) {
				p.removeAttached(AdaptiveWheel.DATA);
			}
			return;
		}
		int completed = AdaptationState.completedCount(read(p));
		if (completed > 0 && p.getHealth() < p.getMaxHealth()) {
			p.heal(Math.min(2.0f, 0.15f * completed)); // healing factor grows with adaptations
		}
	}

	// --------------------------------------------------------------- sword

	private static void tryPurify(ServerPlayer atk, LivingEntity target) {
		if (!atk.getMainHandItem().is(ModItems.SWORD)) return;
		if (!isUndead(target) || target.getType() == EntityType.WITHER) return;
		if (!target.isAlive() || target.getHealth() > target.getMaxHealth() * 0.2f) return;
		if (!(target.level() instanceof ServerLevel sl)) return;

		sl.sendParticles(ParticleTypes.END_ROD, target.getX(), target.getY() + target.getBbHeight() / 2,
			target.getZ(), 25, 0.4, 0.5, 0.4, 0.05);
		sl.playSound(null, target.getX(), target.getY(), target.getZ(),
			SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
		target.hurtServer(sl, sl.damageSources().genericKill(), Float.MAX_VALUE);
		atk.heal(2.0f);
	}

	/** ZombieVillager's package moved between versions, so call startConverting reflectively. */
	private static void cureZombieVillager(LivingEntity zv, ServerPlayer by) {
		try {
			Object converting = zv.getClass().getMethod("isConverting").invoke(zv);
			if (Boolean.TRUE.equals(converting)) return;
			zv.getClass().getMethod("startConverting", UUID.class, int.class).invoke(zv, by.getUUID(), 0);
			if (zv.level() instanceof ServerLevel sl) {
				sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, zv.getX(), zv.getY() + 1, zv.getZ(),
					15, 0.4, 0.5, 0.4, 0.02);
			}
		} catch (ReflectiveOperationException e) {
			AdaptiveWheel.LOGGER.warn("Could not cure zombie villager", e);
		}
	}

	// -------------------------------------------------------------- effects

	private static void play(ServerPlayer p, SoundEvent sound, float volume, float pitch) {
		p.level().playSound(null, p.getX(), p.getY(), p.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
	}

	private static void burst(ServerPlayer p, int count) {
		if (p.level() instanceof ServerLevel sl) {
			sl.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(),
				count, 0.5, 0.8, 0.5, 0.08);
		}
	}
}
