package com.personal.adaptivewheel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.serialization.Codec;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;

public class AdaptiveWheel implements ModInitializer {
	public static final String MOD_ID = "adaptive_wheel";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	/**
	 * Per-player adaptation progress ("key=points|key=points").
	 * Saved with the player, synced to the owning client for the HUD, and NOT
	 * copied on death, so dying resets everything.
	 */
	public static final AttachmentType<String> DATA = AttachmentRegistry.create(
		id("adaptation"),
		builder -> builder
			.initializer(() -> "")
			.persistent(Codec.STRING)
			.syncWith(ByteBufCodecs.STRING_UTF8, AttachmentSyncPredicate.targetOnly())
	);

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModItems.init();

		CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(output -> {
			output.accept(ModItems.WHEEL);
			output.accept(ModItems.SWORD);
		});

		ServerLivingEntityEvents.ALLOW_DAMAGE.register(Adaptation::allowDamage);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(Adaptation::afterDamage);

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTickCount() % 20 != 0) return;
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				Adaptation.tickPlayer(player);
			}
		});

		LOGGER.info("Adaptive Wheel loaded.");
	}
}
